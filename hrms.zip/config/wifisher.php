<?php

return [
    'url' => env('WIFISHER_URL'),

    'key' => env('WIFISHER_API_KEY'),

    'sender' => env('WIFISHER_SENDER'),
];
