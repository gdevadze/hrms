<p>{!! $text !!}</p>
