<button>sdgsd</button>
<script>
    
    window.addEventListener("load", (event) => {
  window.ReactNativeWebView.postMessage('closeWebView');
});

    
</script>