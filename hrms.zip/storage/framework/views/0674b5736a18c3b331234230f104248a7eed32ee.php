<?php $__env->startPush('css'); ?>
    <!--datatable css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css')); ?>" />
    <!--datatable responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">SMS შეტყობინება</h4>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

            </div>
            <!-- container-fluid -->
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">SMS შეტყობინება</h4>
                    </div><!-- end card header -->
                    <div class="card-body">
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e($message); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e($message); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <div class="row gy-4">
                            <form action="<?php echo e(route('messages.send')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="col-xxl-12 col-md-12">
                                    <div>
                                        <label for="choices-multiple-remove-button" class="form-label">თანამშრომლები</label>
                                        <select class="form-control" id="choices-multiple-remove-button" data-choices data-choices-removeItem name="user_ids[]" multiple>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->full_name); ?> - <?php echo e($user->tel); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xxl-12 col-md-12">
                                    <div>
                                        <label for="exampleFormControlTextarea5" class="form-label">ტექსტი</label>
                                        <textarea class="form-control" name="message_text" required id="exampleFormControlTextarea5" rows="3"></textarea>
                                    </div>
                                </div>

                                <div class="col-12 mt-3">
                                    <button class="btn btn-primary" type="submit">გაგზავნა</button>
                                </div>
                            </form>
                            <!--end col-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/pages/form-pickers.init.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/pages/messages/index.blade.php ENDPATH**/ ?>