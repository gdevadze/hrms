<form action="javascript:void(0)" id="user_info" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-xxl-6 col-md-6">
            <label for="basiInput" class="form-label"><?php echo app('translator')->get('date_from'); ?></label>
            <input type="text" class="form-control flatpickr-input" name="start_date" data-provider="flatpickr" data-date-format="d.m.Y" readonly="readonly">
            <span class="text-danger errors start_date_err"></span>
        </div>
        <div class="col-xxl-6 col-md-6">
            <label for="basiInput" class="form-label"><?php echo app('translator')->get('date_to'); ?></label>
            <input type="text" class="form-control flatpickr-input" name="end_date" data-provider="flatpickr" data-date-format="d.m.Y" readonly="readonly">
            <span class="text-danger errors end_date_err"></span>
        </div>
    </div>
    <div class="mt-3">
        <a type="button" class="btn btn-primary waves-effect waves-light save-btn" data-link="<?php echo e(route('user.honorable.reasons.store')); ?>" href="javascript:void(0)"><?php echo app('translator')->get('save'); ?></a>
    </div>
</form>
<script src="<?php echo e(asset('assets/js/pages/form-pickers.init.js')); ?>"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/ka.js"></script>
<script src="<?php echo e(asset('assets/js/geokbd.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('#tel').inputmask({"mask": "599 99 99 99"});
        $('#name_ka').geokbd();
        $('#surname_ka').geokbd();
        flatpickr('.flatpickr-input', {
            minDate: new Date().fp_incr(14)
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/vacations/user/create.blade.php ENDPATH**/ ?>
