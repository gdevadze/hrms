<form action="javascript:void(0)" id="set_time_user" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <p>თარიღი: <?php echo e($formattedDate); ?></p>
        <input type="hidden" name="date" value="<?php echo e($date); ?>">

        <div class="col-xxl-12 col-md-12">
            <label for="basiInput" class="form-label">სამუშაო გრაფიკი</label>
            <select class="form-control" data-choices name="dynamic_working_schedule_id">
                <option value="">აირჩიეთ</option>
                <?php $__currentLoopData = $workingScheduleTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($dynamicTime->id); ?>"><?php echo e($dynamicTime->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="text-danger errors title_err"></span>
        </div>

    </div>
    <div class="mt-3">
        <a type="button" class="btn btn-primary waves-effect waves-light save-btn" data-link="<?php echo e(route('dynamic.working.schedule.set.time.users')); ?>" href="javascript:void(0)"><?php echo app('translator')->get('save'); ?></a>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/working_schedule/dynamic_working_schedule_time_list.blade.php ENDPATH**/ ?>