<?php $__env->startPush('css'); ?>
    <!--datatable css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css')); ?>" />
    <!--datatable responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">დინამიური გრაფიკის მართვა</h4>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

            </div>
            <!-- container-fluid -->
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">დინამიური გრაფიკის მართვა</h4>
                        
                        
                        
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle table-nowrap table-striped-columns mb-0">
                                <thead class="table-light">
                                <tr>

                                    <th scope="col">სახელი, გვარი</th>
                                    <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                                    <th scope="col"><?php echo e(weekDayName('2024','02',$i)); ?><Br><?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?> თებერ</th>
                                    <?php endfor; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($student->full_name); ?>

                                        <input hidden class="user_id_class" data-user-id="<?php echo e($student->id); ?>">
                                    </td>
                                    <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                                        <?php
                                            $converted = str_pad($i, 2, '0', STR_PAD_LEFT);
                                        ?>
                                    <td>

                                        <select style="width: 140px;" class="form-select rounded-pill dynamic_working_schedule" name="dynamic_working_schedule" <?php if(date('Y-'.$month.'-'.str_pad($i, 2, '0', STR_PAD_LEFT)) <= date('Y-m-d')): ?> disabled <?php endif; ?>>
                                            <option selected disabled>აირჩიეთ</option>
                                            <?php $__currentLoopData = $dynamicWorkingScheduleTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($i); ?>" data-user-id="<?php echo e($student->id); ?>" data-month-day="<?php echo e($dynamicTime->id); ?>"
                                                        <?php if($student->dynamic_working_schedule()->where('date', date('Y-'.$month.'-'.$converted))->first()): ?>
                                                            <?php if($student->dynamic_working_schedule()->where('date', date('Y-'.$month.'-'.$converted))->first()->date == date('Y-'.$month.'-'.$converted)): ?>
                                                                <?php if($student->dynamic_working_schedule()->where('date', date('Y-'.$month.'-'.$converted))->first()->dynamic_working_schedule_time_id == $dynamicTime->id): ?> selected <?php endif; ?>
                                                    <?php endif; ?>

                                                    <?php endif; ?>
                                                >
                                                    <?php echo e($dynamicTime->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select></td>
                                    <?php endfor; ?>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            console.log('sdgds')
            $(".dynamic_working_schedule").change(function() {
                console.log('sdgsdss')
                var selectedOption = $(this).find("option:selected");
                var monthDay = selectedOption.data("month-day");

                // Log the selected day to the console
                console.log("Selected day:", monthDay,$(this).find("option[data-month-day='" + monthDay + "']").val());

                // Clear the selected attribute from all options
                $(this).find("option").removeAttr("selected");

                // Set the selected attribute for the corresponding day option
                $(this).find("option[data-month-day='" + monthDay + "']").prop("selected", true);

                let day = $(this).find("option[data-month-day='" + monthDay + "']").val();
                let user = selectedOption.data('user-id');
                console.log(selectedOption.data('user-id'))
                $.ajax({
                    url: "<?php echo e(route('dynamic.working.schedule.update')); ?>",
                    method: "POST", // Or "GET" depending on your needs
                    data: { schedule_time: monthDay,'month': '<?php echo e($month); ?>',day: day,user_id:user,'_token': '<?php echo e(csrf_token()); ?>' }, // Sending the selected day as data
                    success: function(response) {
                        // Handle the AJAX response here
                        console.log("AJAX response:", response);
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX error:", error);
                    }
                });
            });
        });
    </script>

<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/pages/attendance.blade.php ENDPATH**/ ?>