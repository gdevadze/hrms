<table style="width:100%;text-align: center !important;">
        <tr>

            <th style="width: 50px;" rowspan="2">#</th>
            <th rowspan="2">თანამშრომელი</th>

        </tr>
        <tr style="width: 200px !important;">
            <?php for($i = 1; $i <= $month_days; $i++): ?>
                <th><?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT).'.'.$month.'.'.$year); ?></th>
            <?php endfor; ?>
            <th >ხელმოწერა</th>
        </tr>


        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>

                <td><?php echo e($user->user->full_name_en); ?></td>
                <?php for($i = 1; $i <= $month_days; $i++): ?>
                    <?php
                        $dynamicWorkingSchedule = \App\Models\DynamicWorkingSchedule::where('user_id',$user->user_id)->where('date',$year.'-'.$month.'-'.$i)->first()
                    ?>

                    <td style="width: 200px !important;">
                        <b>
                            <font face="Sylfaen" color="#000000">
                                <?php if(isset($dynamicWorkingSchedule) && $dynamicWorkingSchedule->dynamic_working_schedule_time): ?>
                                    <?php if($dynamicWorkingSchedule->dynamic_working_schedule_time_id == 1): ?>
                                        X
                                    <?php else: ?>
                                        <?php echo e(\Carbon\Carbon::parse($dynamicWorkingSchedule->dynamic_working_schedule_time->start_time)->format('H:i').' - '.\Carbon\Carbon::parse($dynamicWorkingSchedule->dynamic_working_schedule_time->end_time)->format('H:i') ?? ''); ?>

                                    <?php endif; ?>

                                <?php endif; ?>
                            </font>
                        </b>
                    </td>
                <?php endfor; ?>
                <td></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/exports/dynamic_shift.blade.php ENDPATH**/ ?>