<button>sdgsd</button>
<script>
    
    window.addEventListener("load", (event) => {
  window.ReactNativeWebView.postMessage('closeWebView');
});

    
</script><?php /**PATH /home/asyasoftware1/public_html/hrms.asyasoftware.ge/resources/views/html.blade.php ENDPATH**/ ?>