<?php $__env->startPush('css'); ?>
    <!--datatable css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css')); ?>" />
    <!--datatable responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">პირადი სამუშაო გრაფიკი</h4>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

            </div>
            <!-- container-fluid -->
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">პირადი სამუშაო გრაფიკი</h4>
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="row gy-4">


                                <div class="table-responsive mt-3">
                                    <table class="table table-hover align-middle table-nowrap table-striped-columns mb-0">
                                        <thead class="table-light">
                                        <tr>

                                            <th scope="col">სამუშაო დღე</th>
                                            <th scope="col">თარიღი</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $dynamicWorkingSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicWorkingSchedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                    <td>
                                                        <?php echo e($dynamicWorkingSchedule->formatted_date); ?> <br> <br> <?php echo e($dynamicWorkingSchedule->formatted_week_day_name); ?>

                                                    </td>
                                                <td>
                                                    <?php if($dynamicWorkingSchedule->dynamic_working_schedule_time_id == 1): ?>
                                                        დასვენების დღე
                                                    <?php else: ?>
                                                        <?php echo e($dynamicWorkingSchedule->dynamic_working_schedule_time->formatted_start_time); ?> სთ - <?php echo e($dynamicWorkingSchedule->dynamic_working_schedule_time->formatted_end_time); ?> სთ
                                                    <?php endif; ?>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            <!--end col-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/pages/form-pickers.init.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/pages/user/working_schedule.blade.php ENDPATH**/ ?>