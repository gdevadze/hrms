<form action="javascript:void(0)" id="user_info1" method="post">
    <?php echo csrf_field(); ?>
<div class="row ">

    <div class="col-md-4">
        <div class="form-group">
            <label for="company_id_1">კომპანია</label>
            <select name="company_id" id="company_id_1" class="form-control">
                <option selected disabled>აირჩიეთ</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->id); ?>" <?php if($company->id == $userCompany->company_id): echo 'selected'; endif; ?>><?php echo e($company->title); ?> (<?php echo e($company->identification_code); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label for="position_id_1">დეპარტამენტი</label>
            <select name="department_id" id="department_id_1" class="form-control">
                <option selected disabled>აირჩიეთ</option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>" <?php if($department->id == $userCompany->department_id): echo 'selected'; endif; ?>><?php echo e($department->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label for="position_id_1">პოზიცია</label>
            <select name="position_id" id="position_id_1" class="form-control">
                <option selected disabled>აირჩიეთ</option>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($position->id); ?>" <?php if($position->id == $userCompany->position_id): echo 'selected'; endif; ?>><?php echo e($position->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label for="working_schedule_id_1">გრაფიკი</label>
            <select name="working_schedule_id" id="working_schedule_id_1" class="form-control">
                <option selected disabled>აირჩიეთ</option>
                <?php $__currentLoopData = $workingSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workingSchedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($workingSchedule->id); ?>" <?php if($workingSchedule->id == $userCompany->working_schedule_id): echo 'selected'; endif; ?>><?php echo e($workingSchedule->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xxl-4 col-md-6">
        <div>
            <label for="contract_dates_1" class="form-label">ხელშეკრულების დაწყების თარიღი</label>
            <input type="text" class="form-control flatpickr-input" name="contract_date" value="<?php echo e($userCompany->formatted_contract_date); ?>" data-provider="flatpickr" data-date-format="d.m.Y" readonly="readonly" id="contract_dates_1" >
            <span class="text-danger errors contract_dates_err"></span>
        </div>
    </div>
    <div class="col-xxl-4 col-md-6">
        <div>
            <label for="contact_end_dates_1" class="form-label">ხელშეკრულების დასრულების თარიღი</label>
            <input type="text" class="form-control flatpickr-input" name="contract_end_date" value="<?php echo e($userCompany->formatted_contract_end_date); ?>" data-provider="flatpickr" data-date-format="d.m.Y" readonly="readonly" id="contact_end_dates_1">
            <span class="text-danger errors contact_end_dates_err"></span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label for="contact_types_1">ხელშეკრულების ტიპი</label>
            <select name="contract_type_id" id="contact_types_1" class="form-control">
                <option selected disabled>აირჩიეთ</option>
                <?php $__currentLoopData = $contractTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($contractType['key']); ?>" <?php if($contractType['key'] == $userCompany->contract_type_id): echo 'selected'; endif; ?>><?php echo e($contractType['title']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="mt-3">
    <a type="button" class="btn btn-primary waves-effect waves-light save-btn" data-link="<?php echo e(route('users.update.user.company',$userCompany->id)); ?>" href="javascript:void(0)"><?php echo app('translator')->get('save'); ?></a>
</div>
</form>

<script>
    flatpickr('.flatpickr-input', {
        allowInput: true,
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/users/edit_user_company.blade.php ENDPATH**/ ?>