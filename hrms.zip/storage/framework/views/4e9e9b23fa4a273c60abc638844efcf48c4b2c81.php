<div class="table-responsive">
    <table border="0" cellpadding="0" cellspacing="0" width="465">
        <colgroup>
            <col width="151"/>
            <col width="81" span="3"/>
            <col width="71"/>
        </colgroup>
        <tbody>
        <!-- Table header with dates for each day -->
        <?php
            // Create a collection of all dates in the range
            $dateRange = collect();
            $currentDate = $start->copy();

            while ($currentDate->lte($end)) {
                $dateRange->push($currentDate->copy());
                $currentDate->addDay();
            }
        ?>
        <tr height="20">
            <td >#</td>
            <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td scope="col" class="date-clickable" data-date="<?php echo e($date->format('Y-m-d')); ?>"><?php echo e(weekDayName($date->year, $date->month, $date->day)); ?><br><?php echo e($date->translatedFormat('d M')); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>

        <!-- Data rows for each user -->
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td rowspan="2"><?php echo e($user['full_name']); ?></td>
                <?php $__currentLoopData = $user->movements()->whereDate('start_date','>=',$startDate)->whereDate('start_date','<=',$endDate)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($date->format('Y-m-d') == \Carbon\Carbon::parse($res->start_date)->format('Y-m-d')): ?>
                            <td align="right"><?php echo e($date->format('Y-m-d')); ?></td>
                            <td align="right"><?php echo e(\Carbon\Carbon::parse($res->start_date)->format('Y-m-d')); ?></td>
                        <?php else: ?>
                            <td align="right">დ</td>
                            <td align="right">დ</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <?php $__currentLoopData = $user->movements()->whereDate('start_date','>=',$startDate)->whereDate('start_date','<=',$endDate)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td colspan="2" height="20">0</td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <style>
        td {
            border: 1px solid #00000052;
        }
    </style>
</div>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/exports/movements_excel.blade.php ENDPATH**/ ?>