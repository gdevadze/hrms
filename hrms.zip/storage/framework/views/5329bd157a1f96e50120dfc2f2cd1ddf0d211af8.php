<div class="live-preview">
    <div class="accordion custom-accordionwithicon-plus" id="accordionWithplusicon">
        <?php $__currentLoopData = $yearHolidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $yearHoliday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item">
                <h2 class="accordion-header" id="holiday-<?php echo e($key); ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accor_plusExamplecollapse<?php echo e($key); ?>" aria-expanded="false" aria-controls="accor_plusExamplecollapse2">
                        <?php echo app('translator')->get('holidays'); ?> - <?php echo e($key); ?>

                    </button>
                </h2>
                <div id="accor_plusExamplecollapse<?php echo e($key); ?>" class="accordion-collapse collapse" aria-labelledby="holiday-<?php echo e($key); ?>" data-bs-parent="#accordionWithplusicon">
                    <div class="accordion-body">
                        <div class="row">
                            <?php $__currentLoopData = $yearHoliday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3">
                                    <div class="alert alert-success alert-dismissible alert-label-icon label-arrow fade show" role="alert">
                                        <i class="ri-check-double-line label-icon"></i><strong><?php echo e($holiday->title); ?></strong>
                                        <br>
                                        <?php echo e($holiday['formatted_date']); ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('holiday-edit')): ?>
                                            <button type="button" class="btn" style="position: absolute;
    top: 0;
    right: 0;
    z-index: 2;
    font-size: 18px;
    padding: 1rem 1rem;"><i class="fa fa-edit"></i></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/holidays/index.blade.php ENDPATH**/ ?>