<style>
    tr>th:first-child, tr>td:first-child {
        position: sticky;
        left: 0;
    }
</style>
<div class="table-responsive">
    <form id="movementsForm">
        <?php echo csrf_field(); ?>
        <table class="table align-middle table-nowrap table-striped-columns mb-0">
            <thead class="table-light">
            <tr>
                <th>თანამშრომელი</th>
                <?php for($day = 1; $day <= $month_days; $day++): ?>
                    <th><?php echo e($day.' '.getMonthName($date->month)); ?> <br> <?php echo e(weekDayName($date->year, $date->month, $day)); ?></th>
                <?php endfor; ?>
                <th>ჯამი</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="background-color: white;"><?php echo e($user->full_name); ?></td>
                    <?php for($day = 1; $day <= $month_days; $day++): ?>
                        <?php
                            $currentDate = \Carbon\Carbon::create($date->year, $date->month, $day);
                            $movement = $user->movements->first(function ($m) use ($currentDate) {
                                return $currentDate->isSameDay($m->start_date) || $currentDate->isSameDay($m->end_date);
                            });
                        ?>
                        <td>
                            <?php if($movement): ?>
                            <div class="col-xxl-12 col-md-12">
                                <input type="hidden" name="user_id[]" value="<?php echo e($user->id); ?>">
                                <input type="hidden" name="date[]" value="<?php echo e($currentDate->toDateString()); ?>">
                                <div>
                                    <label class="form-label">ნამუშევარი საათი</label>
                                    <input type="text" class="form-control worked-hours" name="worked_hours[]"
                                           value="<?php echo e($movement ? $movement->worked_hours : ''); ?>">
                                </div>
                                <div>
                                    <label class="form-label">ღამე ნამუშევარი საათი</label>
                                    <input type="text" class="form-control at-night-hours" name="at_night_hours[]"
                                           value="<?php echo e($movement ? $movement->at_night_hours : ''); ?>">
                                </div>
                            </div>
                                <?php endif; ?>
                        </td>
                    <?php endfor; ?>
                    <td style="background-color: white;"><?php echo e($user->movements()->sum('worked_hours')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="button" id="saveMovements" class="btn btn-primary mt-3">Save</button>
    </form>
</div>

<script>
    $(document).ready(function () {
        $('#saveMovements').click(function () {
            let formDataArray = $('#movementsForm').serializeArray();
            let chunkSize = 900;
            let totalChunks = Math.ceil(formDataArray.length / chunkSize);

            function sendChunk(chunkIndex) {
                if (chunkIndex >= totalChunks) {
                    alert('All data saved successfully!');
                    return;
                }

                let chunkData = formDataArray.slice(chunkIndex * chunkSize, (chunkIndex + 1) * chunkSize);

                $.ajax({
                    url: '<?php echo e(route("reports.confirmation_movements.update.data")); ?>',
                    type: 'POST',
                    data: $.param(chunkData),
                    headers: {
                        'X-CSRF-TOKEN': $('input[name=_token]').val()
                    },
                    success: function () {
                        sendChunk(chunkIndex + 1); // Send the next chunk
                    },
                    error: function (xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            }

            sendChunk(0); // Start sending chunks
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/reports/confirmation_movements.blade.php ENDPATH**/ ?>