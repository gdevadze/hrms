<!DOCTYPE html>

<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title></title>
    <meta name="generator" content="LibreOffice 7.4.2.3 (Linux)"/>
    <meta name="created" content="2015-06-05T18:17:20"/>
    <meta name="changed" content="2023-06-15T08:32:12"/>
    <meta name="AppVersion" content="16.0300"/>

    <style type="text/css">
        body,div,table,thead,tbody,tfoot,tr,th,td,p { font-family:"Calibri"; font-size:x-small }
        a.comment-indicator:hover + comment { background:#ffd; position:absolute; display:block; border:1px solid black; padding:0.5em;  }
        a.comment-indicator { background:red; display:inline-block; border:1px solid black; width:0.5em; height:0.5em;  }
        comment { display:none;  }
    </style>

</head>

<body>
<table cellspacing="0" border="0">
    <colgroup width="169"></colgroup>
    <colgroup span="2" width="67"></colgroup>
    <colgroup width="72"></colgroup>
    <colgroup width="76"></colgroup>
    <colgroup width="84"></colgroup>
    <colgroup width="136"></colgroup>
    <colgroup width="89"></colgroup>
    <colgroup width="58"></colgroup>
    <colgroup width="67"></colgroup>
    <colgroup width="90"></colgroup>
    <colgroup width="65"></colgroup>
    <colgroup width="88"></colgroup>
    <colgroup width="65"></colgroup>
    <colgroup span="2" width="67"></colgroup>
    <tr>
        <td height="20" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px solid #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000" colspan=11 rowspan=4 height="80" align="center" valign=middle bgcolor="#FFFFFF"><font size=6 color="#000000">შვებულების ფორმა</font></td>
        <td style="border-top: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">შევსების თარიღი</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="right" valign=bottom bgcolor="#FFFFFF" sdval="45235" sdnum="1033;0;M/D/YYYY"><b><font color="#000000">11/5/2023</font></b></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-bottom: 2px solid #000000; border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000; border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px solid #000000; border-left: 2px solid #000000" height="19" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000; border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" height="19" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">სახელი/გვარი</font></b></td>
        <td colspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">კომპანია</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">„ASYA SOFTWARE“ A.Ş. </font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" height="19" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td colspan=2 align="center" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="center" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" height="19" align="left" valign=bottom><b><font color="#000000">გიორგი დევაძე</font></b></td>
        <td colspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">პ/ნ 61004066729</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font face="Times New Roman" color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"> </font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-bottom: 2px solid #000000; border-left: 2px solid #000000" height="20" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-bottom: 2px solid #000000; border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=2 rowspan=11 height="219" align="center" valign=middle bgcolor="#FFFFFF"><b><font size=6 color="#000000">შვებულების აღწერა</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 2px double #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">შვებულების დაწყების თარიღი</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 2px double #000000; border-left: 2px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">შვებულების დამთავრების თარიღი</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 2px double #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">მუშაობის დაწყების თარიღი</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 2px double #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">შვებულების ვადა</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px double #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF" sdval="45235" sdnum="1033;0;M/D/YYYY"><b><font color="#000000">11/5/2023</font></b></td>
        <td style="border-top: 2px double #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF" sdval="45235" sdnum="1033;0;M/D/YYYY"><b><font color="#000000">11/5/2023</font></b></td>
        <td style="border-top: 2px double #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF" sdnum="1033;0;M/D/YYYY"><b><font color="#000000">15/5/2023</font></b></td>
        <td style="border-top: 2px double #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">1 GÜN</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px solid #000000; border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" colspan=2 rowspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br><img src="475075e92b6497410d29341a467ce3a0_html_71f0af5b69fa8256.png" width=19 height=15 hspace=65 vspace=12>
            </font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" rowspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br><img src="475075e92b6497410d29341a467ce3a0_html_e29164283ce4002f.png" width=19 height=15 hspace=35 vspace=12>
            </font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000" colspan=2 rowspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br><img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=67 vspace=12>
            </font></td>
        <td style="border-top: 2px solid #000000; border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">წლიური</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">ანაზღაურებადი</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font face="Sylfaen" color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">ანაზღაურების გარეშე</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td colspan=2 rowspan=2 align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br><img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=65 vspace=12>
            </font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"> </font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">საპატიო</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000">განმარტება:</font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 1px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font face="Times New Roman" color="#000000"><br></font></b></td>
        <td style="border-right: 1px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-left: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-right: 1px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td style="border-right: 2px solid #000000" align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 2px solid #000000; border-bottom: 1px solid #000000; border-left: 2px solid #000000; border-right: 1px solid #000000" colspan=2 rowspan=2 height="39" align="center" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 2px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">დასაქმებული</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">მენეჯერი</font></b></td>
        <td style="border-top: 2px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">დირექტორი</font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"> </font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 2px solid #000000; border-right: 1px solid #000000" colspan=2 rowspan=2 height="38" align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">სახელი/გვარი</font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font size=3 color="#000000">Giorgi Devadze</font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">GOKBERK TAMAÇ</font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=2 align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000"><br></font></b></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td style="border-top: 1px solid #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 1px solid #000000" colspan=2 rowspan=3 height="58" align="center" valign=middle bgcolor="#FFFFFF"><b><font color="#000000">ხელმოწერა</font></b></td>
        <td style="border-top: 1px solid #000000; border-bottom: 2px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=3 align="center" valign=middle bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 1px solid #000000; border-bottom: 2px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=3 align="center" valign=middle bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 1px solid #000000; border-bottom: 2px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 rowspan=3 align="center" valign=middle bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td style="border-top: 1px solid #000000; border-bottom: 2px solid #000000; border-left: 1px solid #000000; border-right: 2px solid #000000" colspan=3 rowspan=3 align="center" valign=middle bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
    <tr>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
        <td align="left" valign=bottom bgcolor="#FFFFFF"><font color="#000000"><br></font></td>
    </tr>
</table>
<img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=65 vspace=12>
<img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=65 vspace=12>
<img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=65 vspace=12>
<img src="475075e92b6497410d29341a467ce3a0_html_2852db42c2873754.png" width=19 height=15 hspace=65 vspace=12>
<!-- ************************************************************************** -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/exports/vacation.blade.php ENDPATH**/ ?>