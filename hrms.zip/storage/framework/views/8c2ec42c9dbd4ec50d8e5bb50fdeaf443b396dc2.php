<table style="width:100%;text-align: center !important;">
    <tr>

        <th style="width: 50px;" rowspan="2">#</th>
        <th rowspan="2">თანამშრომელი</th>
        <th rowspan="2">თანამდებობა</th>
        <th rowspan="2">ტაბულის ნომერი/პირადი ნომერი</th>



    </tr>
    <tr>
        <?php for($i = 1; $i <= $month_days; $i++): ?>
            <th colspan="1" style="height: 110px; width: 20px !important;"><?php echo e($i); ?>.<?php echo e($month); ?>.<?php echo e($year); ?></th>
        <?php endfor; ?>
        <th rowspan="1">დღე</th>
        <th>ჯამი</th>
        <th>დასვენების <br> დღეები</th>

    </tr>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="height: 90px;">
            <td><?php echo e($key+1); ?></td>

            <td><?php echo e($user['data']['full_name']); ?></td>
            <td><?php echo e($user['data']['position_title']); ?></td>
            <td><?php echo e($user['data']['personal_num']); ?></td>
            <?php
                $totalWorkedHours = 0;
                $totalWorkedDays = 0;
                $totalHolidays = 0;
            ?>
            <?php $__currentLoopData = $user['result']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><b>
                        <font face="Sylfaen" color="#000000">
                            <?php if(isset($res['value'])): ?>
                                <?php if($res['value'] == ''): ?>
                                    <?php echo e($res['start_date']); ?> - <?php echo e($res['end_date']); ?>

                                    <br>
                                    ნამ. სთ: <?php echo e($res['worked_hours']); ?><?php if(isset($res['minutes'])): ?>:<?php echo e($res['minutes']); ?><?php endif; ?>
                                <?php else: ?>

                                    <?php echo e($res['value']); ?>


                                <?php endif; ?>
                            <?php endif; ?>
                        </font>
                    </b></td>
                <?php
                    if(isset($res['value']) && ($res['value'] == 'დ' || $res['value'] == 'X')){
                        $totalHolidays += 1;
                    }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <td><center><?php echo e($user['data']['must_working_days']); ?></center></td>
            <td><center><?php echo e($user['data']['summary_worked_hours']); ?></center></td>
            <td><center><?php echo e($totalHolidays); ?></center></td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<style>
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
</style>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/exports/worked_hours.blade.php ENDPATH**/ ?>