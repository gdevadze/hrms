<div id="scrollbar">
    <div class="container-fluid">

        <div id="two-column-menu">
        </div>
        <ul class="navbar-nav" id="navbar-nav">
            <li class="nav-item">
                <a class="nav-link menu-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="ri-honour-line"></i> <span data-key="t-widgets"><?php echo app('translator')->get('home'); ?></span>
                </a>
            </li>


                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarDashboards" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="sidebarDashboards">
                        <i class="ri-time-line"></i> <span data-key="t-dashboards"><?php echo app('translator')->get('schedule'); ?></span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarDashboards">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="<?php echo e(route('holidays.index')); ?>" class="nav-link"
                                   data-key="t-analytics"> <?php echo app('translator')->get('holidays'); ?> </a>
                            </li>
                            <?php if(currentUser()->working_schedule_id == 2): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('user.working.schedule')); ?>" class="nav-link"
                                   data-key="t-analytics">პირადი სამუშაო გრაფიკი</a>
                            </li>
                            <?php endif; ?>
                            <?php if(currentUser()->hasRole('System Administrator')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('working.schedule.index')); ?>" class="nav-link"
                                   data-key="t-analytics"> <?php echo app('translator')->get('work_schedule'); ?> </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('dynamic.working.schedule.time.index')); ?>" class="nav-link"
                                   data-key="t-analytics"> დინამიური გრაფიკის სამუშაო დროის მართვა </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('dynamic.working.schedule.index')); ?>" class="nav-link"
                                   data-key="t-analytics"> დინამიური გრაფიკის მართვა </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>

            <?php if(currentUser()->hasRole('System Administrator')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('vacations.index')); ?>">
                        <i class="ri-calendar-2-line"></i> <span data-key="t-widgets"><?php echo app('translator')->get('vacations'); ?></span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(currentUser()->hasRole('Admin')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('reports.movements.index')); ?>">
                        <i class="ri-calendar-2-line"></i> <span data-key="t-widgets">გატარებები</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(!currentUser()->hasRole('მომხმარებელი') && !currentUser()->hasRole('Admin')): ?>





                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarEmployees" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="sidebarDashboards">
                        <i class="ri-account-box-fill"></i> <span data-key="t-dashboards"><?php echo app('translator')->get('employees'); ?></span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarEmployees">
                        <ul class="nav nav-sm flex-column">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('users.index')); ?>" class="nav-link"
                                   data-key="t-analytics"> <?php echo app('translator')->get('employees_management'); ?> </a>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('users.delays')); ?>" class="nav-link"
                                   data-key="t-analytics"> დაგვიანების მიზეზები </a>
                            </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('users.subordinates')); ?>" class="nav-link"
                                       data-key="t-analytics"> დაქვემდებარებული თანამშრომლები </a>
                                </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>
            <?php if(currentUser()->hasRole('System Administrator')): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarReports" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="sidebarReports">
                        <i class="bx bxs-report"></i> <span data-key="t-dashboards">რეპორტები</span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarReports">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.movements.index')); ?>" class="nav-link"
                                   data-key="t-analytics">თანამშრომლის მოძრაობის რეპორტი</a>
                            </li>
                            <li class="nav-item">
                                <a href="#sidebarAccount" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAccount" data-key="t-level-1.2"> თანამშრომლის ნამუშევარი საათის რეპორტი
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarAccount">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('reports.worked.hours.index',1)); ?>" class="nav-link" data-key="t-level-2.1"> გრაფიკით </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('reports.worked.hours.index',2)); ?>" class="nav-link" data-key="t-level-2.1"> რეალური </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="#sidebarAccount1" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAccount" data-key="t-level-1.2"> ტაბელი
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarAccount1">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('reports.hr_table.index',1)); ?>" class="nav-link" data-key="t-level-2.1"> გრაფიკით </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('reports.hr_table.index',2)); ?>" class="nav-link" data-key="t-level-2.1"> რეალური </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>




















                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.confirmation_movements.index')); ?>" class="nav-link"
                                   data-key="t-analytics">თანამშრომლის ნამუშევარი საათის დადასტურება</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.rs.index')); ?>" class="nav-link"
                                   data-key="t-analytics">RS-ის რეპორტი</a>
                            </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>

            <?php if(currentUser()->id == 1): ?>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarSettings" data-bs-toggle="collapse" role="button"
                       aria-expanded="false" aria-controls="sidebarDashboards">
                        <i class="ri-settings-2-line"></i> <span data-key="t-dashboards">პარამეტრები</span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarSettings">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="<?php echo e(route('settings.general.index')); ?>" class="nav-link"
                                   data-key="t-analytics">ზოგადი პარამეტრები</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('settings.departments.index')); ?>" class="nav-link"
                                   data-key="t-analytics">დეპარტამენტები</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('settings.positions.index')); ?>" class="nav-link"
                                   data-key="t-analytics">პოზიციები</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('languages.index')); ?>" class="nav-link"
                                   data-key="t-analytics">თარგმანი</a>
                            </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>



            <li class="menu-title"><span data-key="t-menu">MY</span></li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="<?php echo e(route('user.vacations.index')); ?>">
                    <i class="ri-calendar-2-line"></i> <span data-key="t-widgets">პირადი <?php echo app('translator')->get('vacations'); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-link" href="<?php echo e(route('user.movements.index')); ?>">
                    <i class="fa fa-map-signs"></i> <span data-key="t-widgets">პირადი <?php echo app('translator')->get('movements'); ?></span>
                </a>
            </li>



            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            



            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

        </ul>
    </div>
    <!-- Sidebar -->
</div>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>