<div class="table-responsive">
    <table class="table table-hover align-middle table-nowrap table-striped-columns mb-0">
        <thead class="table-light">
        <tr>

            <th scope="col">სახელი, გვარი</th>
            <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                <th scope="col"><?php echo e(weekDayName($month,$i)); ?><Br><?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?> <?php echo e($monthName); ?></th>
            <?php endfor; ?>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>

                    <td><?php echo e($student->full_name); ?>

                        <input hidden class="user_id_class" data-user-id="<?php echo e($student->id); ?>">
                    </td>
                    <?php for($i = 1; $i <= $daysInMonth; $i++): ?>

                            <?php
                                $converted = str_pad($i, 2, '0', STR_PAD_LEFT);
                            ?>
                            <td>
                                <?php echo e($student->dynamic_working_schedule()->where('date', date('Y-'.$month.'-'.$converted))->first()->dynamic_working_schedule_time->title ?? ''); ?>

                                </td>

                    <?php endfor; ?>

                </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/asyasoftware1/public_html/hrms.asyasoftware.ge/resources/views/exports/dynamic_working_schedule.blade.php ENDPATH**/ ?>