<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
    </style>
    <title>Report - <?php echo e($user->personal_num); ?></title>
</head>
<body>

<table>

    <tr>
        <td colspan="3">
            სახელი, გვარი: <?php echo e($user['full_name']); ?>

            <br>
            <br>
            ტელ: <?php echo e($user['tel']); ?>

        </td>
        <td colspan="2">
            პირადი ნომერი: <?php echo e($user['personal_num']); ?>

        </td>
    </tr>

    <tr>
        <td></td>
        <td><?php echo app('translator')->get('day'); ?></td>
        <td><?php echo app('translator')->get('start'); ?></td>
        <td><?php echo app('translator')->get('finish'); ?></td>
        <td><?php echo app('translator')->get('hours_worked'); ?></td>

    </tr>
    <?php $__currentLoopData = $user['movements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($movement->week_day_name); ?></td>
            <td>
                <?php if($movement->checkUser($user['working_schedule']['week_days'])): ?>
                    <span ><?php echo e($movement->formatted_start_date); ?></span>
                <?php else: ?>
                    <span><?php echo e($movement->formatted_start_date); ?></span>
                <?php endif; ?>
            </td>
            <td>
                <?php if($movement->checkUser($user['working_schedule']['week_days'],true)): ?>
                    <span ><?php echo e($movement->formatted_end_date); ?></span>
                <?php else: ?>
                    <span ><?php echo e($movement->formatted_end_date); ?></span>
                <?php endif; ?>
            </td>
            <td><?php echo e($movement->worked_hours['hours']); ?></td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!--<tr>-->
    <!--    <td colspan="5">-->
    <!--        <?php echo app('translator')->get('workdays'); ?>:<b class="text-danger"> <?php echo e($workingAndMissedDays['working_days']); ?></b>, <?php echo app('translator')->get('to_miss'); ?>:<b class="text-danger"> <?php echo e($workingAndMissedDays['missed_days']); ?></b>, <?php echo app('translator')->get('late'); ?>:<b class="text-danger"> <?php echo e($employeeLateIncomes); ?></b>, <?php echo app('translator')->get('go_early'); ?>:<b class="text-danger"> <?php echo e($employeeGoEarly); ?></b>, <?php echo app('translator')->get('actual_working_days'); ?>:<b class="text-danger"> <?php echo e($workingAndMissedDays['actual_working_days']); ?></b>-->
    <!--    </td>-->
    <!--</tr>-->

</table>
</body>
</html>
<?php /**PATH /home/asyasoftware1/public_html/hrms.asyasoftware.ge/resources/views/exports/movements_pdf.blade.php ENDPATH**/ ?>