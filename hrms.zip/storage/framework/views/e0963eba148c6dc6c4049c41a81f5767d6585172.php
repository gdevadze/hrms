<p><?php echo $text; ?></p>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/notifications/email.blade.php ENDPATH**/ ?>