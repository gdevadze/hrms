<p><?php echo $text; ?></p>
<?php /**PATH /home/asyasoftware1/public_html/hrms.asyasoftware.ge/resources/views/general/notifications/email.blade.php ENDPATH**/ ?>