<?php $__env->startPush('css'); ?>
    <!--datatable css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css')); ?>"/>
    <!--datatable responsive css-->
    <link rel="stylesheet"
          href="<?php echo e(asset('assets/cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">თანამშრომლის მოძრაობის რეპორტი</h4>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

            </div>
            <!-- container-fluid -->
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header align-items-center d-flex">
                        <h4 class="card-title mb-0 flex-grow-1">თანამშრომლის მოძრაობის რეპორტი</h4>
                        
                        
                        
                        
                    </div><!-- end card header -->
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-lg-12 col-md-12">
                                <div class="mb-3">
                                    <label for="company_id" class="form-label text-muted">კომპანია</label>
                                    <select class="form-control" data-choices name="choices-single-default" id="company_id">
                                        <option value="">აირჩიეთ</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->title); ?> - <?php echo e($company->identification_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="table-responsive">
                            <table id="positions" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col"><?php echo app('translator')->get('full_name'); ?></th>
                                    <th scope="col">პირადი ნომერი</th>
                                    <th scope="col">დაბადების თარიღი</th>
                                    <th scope="col"><?php echo app('translator')->get('phone'); ?></th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                                <tfoot>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col"><?php echo app('translator')->get('full_name'); ?></th>
                                    <th scope="col">პირადი ნომერი</th>
                                    <th scope="col">დაბადების თარიღი</th>
                                    <th scope="col"><?php echo app('translator')->get('phone'); ?></th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal_form_detail" tabindex="-1" role="dialog"
         aria-labelledby="exampleStandardModalLabel"
         data-bs-backdrop="static"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal_title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="htmlDisplay"></div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><i
                            class="fa fa-times mr-2"
                            aria-hidden="true"></i> დახურვა
                    </button>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js')); ?>"></script>

    <script>
        let table;
        let save_method;
        $(document).ready(function () {

            table = $('#positions').DataTable({
                processing: true,
                order: [[0, 'desc']],
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('reports.rs.ajax')); ?>",
                    type: 'POST',
                    data: function (d) {
                        d.company_id = $('#company_id').val()
                        d._token = '<?php echo e(csrf_token()); ?>'
                    }
                },
                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'full_name', name: 'tel'},
                    {data: 'personal_num', name: 'personal_num'},
                    {data: 'formatted_birthdate', name: 'birthdate'},
                    {data: 'tel', name: 'tel'},
                ],
                createdRow: function (row, data, index) {
                    $(row).find('[data-bs-toggle="tooltip"]').tooltip();
                }
            });
            $.fn.dataTable.ext.errMode = 'none';

            $('#company_id').on('change', function () {
                table.draw();
            });
        });

        $(document.body).on('click', '#add_position', function () {
            $('#modal_form_detail').modal('show'); // show bootstrap modal when complete loaded
            $(".htmlDisplay").html('<h3 align=center class=text-warning><i class="fa fa-spinner fa-spin" style="font-size:24px"></i> <?php echo app('translator')->get('wait'); ?>...</h3>');
            $.ajax({
                url: "<?php echo e(route('settings.positions.create')); ?>",
                method: "POST",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                },
                success: function (msg) {
                    if (msg.status == 0) {
                        $('.htmlDisplay').html(msg.html);
                        $('#modal_title').html(msg.title)
                        $('modal_form_detail').modal('hide');
                    }else if(msg.status == 2){
                        $('.htmlDisplay').html(`<h3 align=center class=text-danger>${msg.error}</h3>`);
                    }
                    else {
                        $('.htmlDisplay').html('<h3 align=center class=text-danger><i class="fa fa-spin fa-spinner"></i> ამანათზე ინფორმაცია ვერ მოიძებნა!</h3>');
                    }
                },
                error: function () {
                    alert('შეცდომა, გაიმეორეთ მოქმედება.');
                }
            })
        })

        $(document.body).on('click', '.save-btn', function () {
            let form = $('#user_info').serialize();
            let $this = $(this)
            console.log($this.data('link'))
            $this.html('<i class="fa fa-spin fa-spinner"></i> დაელოდეთ...');
            $this.prop('disabled', true);
            $.ajax({
                url: $this.data('link'),
                method: "POST",
                data: form,
                success: function (response) {
                    if (response.status == 0) {
                        Swal.fire('წარმატებული!', response.msg, 'success');
                        $this.html('შენახვა');
                        reload()
                        $this.prop('disabled', false);
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 422) { // when status code is 422, it's a validation issue
                        $('.errors').html('');
                        $.each(xhr.responseJSON.errors, function (i, error) {
                            $('.' + i + '_err').html(error);
                        });
                    }
                    $this.html('შენახვა');
                    $this.prop('disabled', false);
                }
            })
        })

        function reload() {
            table.ajax.reload();
        }

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asyasoftware1/public_html/hrms.asyasoftware.ge/resources/views/pages/reports/rs.blade.php ENDPATH**/ ?>