<style>
    tr>th:first-child,tr>td:first-child {
        position: sticky;
        left: 0;
    }
</style>
<div class="table-responsive">
<table class="table  align-middle table-nowrap table-striped-columns mb-0">
    <?php
        // Create a collection of all dates in the range
        $dateRange = collect();
        $currentDate = $start->copy();

        while ($currentDate->lte($end)) {
            $dateRange->push($currentDate->copy());
            $currentDate->addDay();
        }
    ?>
    <thead class="table-light">
    <tr>
        <th scope="col">სახელი, გვარი</th>
        <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th scope="col" class="date-clickable" data-date="<?php echo e($date->format('Y-m-d')); ?>"><?php echo e(weekDayName($date->year, $date->month, $date->day)); ?><br><?php echo e($date->translatedFormat('d M')); ?></th>
            <?php if(weekDayName($date->year, $date->month, $date->day) == 'კვირა'): ?>
                <th scope="col">ჯამური დრო</th>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
    <?php
        $totalWorkingHours = 0;
    ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="background-color: white;"><?php echo e($student->user->full_name); ?><input hidden class="user_id_class" data-user-id="<?php echo e($student->id); ?>"></td>
            <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $dy = $student->dynamic_working_schedule->firstWhere('date', $date->format('Y-m-d'));
                    $hours = 0;
                ?>

                <td>
                    <?php if($dy && $dy->dynamicWorkingScheduleTime): ?>
                        <?php
                            $time = $dy->dynamicWorkingScheduleTime;
                            $workedSeconds = \Carbon\Carbon::parse($time->start_time)->addMinutes($time->break_duration)->diffInSeconds($time->end_time);
                            $hours = (int)($workedSeconds / 3600);
                            $totalWorkingHours += $hours;
                        ?>
                    <?php endif; ?>
                    <select style="width: 160px;" class="form-select rounded-pill dynamic_working_schedule" name="dynamic_working_schedule">
                        <option selected disabled>აირჩიეთ</option>
                        <?php $__currentLoopData = $dynamicWorkingScheduleTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($date->format('d')); ?>" data-month="<?php echo e($date->format('m')); ?>" data-year="<?php echo e($date->format('Y')); ?>" data-user-id="<?php echo e($student->user_id); ?>" data-month-day="<?php echo e($dynamicTime->id); ?>" <?php echo e(optional($dy)->dynamic_working_schedule_time_id == $dynamicTime->id ? 'selected' : ''); ?>><?php echo e($dynamicTime->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <?php if($date->isSunday()): ?>
                    <th><?php echo e($student->dynamic_working_schedule->whereBetween('date', [$date->startOfWeek()->format('Y-m-d'), $date->endOfWeek()->format('Y-m-d')])->sum('workedHours') ?? ''); ?> / 40</th>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<!-- Modal Structure -->
<div class="modal fade" id="dateModal" tabindex="-1" aria-labelledby="dateModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal_title"><?php echo app('translator')->get('user_information'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="htmlDisplayTimeList"></div>
            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><i
                        class="fa fa-times mr-2"
                        aria-hidden="true"></i> <?php echo app('translator')->get('close'); ?>
                </button>
            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function () {
        $(".date-clickable").click(function () {
            $('#dateModal').modal('show'); // show bootstrap modal when complete loaded
            $(".htmlDisplayTimeList").html('<h3 align=center class=text-warning><i class="fa fa-spinner fa-spin" style="font-size:24px"></i> <?php echo app('translator')->get('wait'); ?>...</h3>');
            $.ajax({
                url: "<?php echo e(route('dynamic.working.schedule.time.list.render')); ?>",
                method: "POST",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    'date': $(this).data('date'),
                },
                success: function (msg) {
                    if (msg.status == 0) {
                        $('.htmlDisplayTimeList').html(msg.html);
                        // $('modal_form_detail').modal('hide');
                        // loadDynamicWorkingTable()
                    }
                },
                error: function () {
                    alert('შეცდომა, გაიმეორეთ მოქმედება.');
                }
            })
        });

        $(".dynamic_working_schedule").change(function () {
            let selectedOption = $(this).find("option:selected");
            let monthDay = selectedOption.data("month-day");
            let month = selectedOption.data("month");
            let year = selectedOption.data("year");

            // Clear the selected attribute from all options
            $(this).find("option").removeAttr("selected");

            // Set the selected attribute for the corresponding day option
            $(this).find("option[data-month-day='" + monthDay + "']").prop("selected", true);

            let day = $(this).find("option[data-month-day='" + monthDay + "']").val();
            let user = selectedOption.data('user-id');
            $.ajax({
                url: "<?php echo e(route('dynamic.working.schedule.update')); ?>",
                method: "POST", // Or "GET" depending on your needs
                data: {
                    schedule_time: monthDay,
                    'month': month,
                    'year': year,
                    day: day,
                    user_id: user,
                    '_token': '<?php echo e(csrf_token()); ?>' }, // Sending the selected day as data
                success: function(response) {
                    // Handle the AJAX response here
                    console.log("AJAX response:", response);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", error);
                }
            });
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/working_schedule/dynamic_working_schedule.blade.php ENDPATH**/ ?>