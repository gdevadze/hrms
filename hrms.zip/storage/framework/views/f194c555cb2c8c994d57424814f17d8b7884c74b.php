<style>
    tr>th:first-child,tr>td:first-child {
        position: sticky;
        left: 0;
    }
</style>

<div class="table-responsive">
    <table class="table  align-middle table-nowrap table-striped-columns mb-0">
        <thead class="table-light">
        <tr>
            <th scope="col">სახელი, გვარი</th>
            <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                <th scope="col"><?php echo e(weekDayName($year, $month, $i)); ?><br><?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?> <?php echo e($monthName); ?></th>
                <?php if(weekDayName($year, $month, $i) == 'კვირა'): ?>
                    <th scope="col">ჯამური დრო</th>
                <?php endif; ?>
            <?php endfor; ?>
        </tr>
        </thead>
        <tbody>
        <?php
            $totalWorkingHours = 0;
        ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="background-color: white;"><?php echo e($student->user->full_name); ?><input hidden class="user_id_class" data-user-id="<?php echo e($student->id); ?>"></td>
                <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                    <?php
                        $converted = str_pad($i, 2, '0', STR_PAD_LEFT);
                        $date = \Carbon\Carbon::createFromFormat("Y-m-d", "{$year}-{$month}-{$converted}");
                        $hours = 0;
                    ?>

                    <td>
                        <?php
                            $dy = $student->dynamic_working_schedule()->where('date', date($year.'-'.$month.'-'.$converted))->first();
                        ?>
                        <?php if($dy): ?>
                            <?php
                                $time = \App\Models\DynamicWorkingScheduleTime::findOrFail($dy->dynamic_working_schedule_time_id);
                                $workedSeconds = \Carbon\Carbon::parse($time->start_time)->addMinutes($time->break_duration)->diffInSeconds($time->end_time);
                                $hours += (int)($workedSeconds / 3600);
                                $totalWorkingHours += $hours;
                            ?>
                        <?php endif; ?>
                        <select style="width: 160px;" class="form-select rounded-pill dynamic_working_schedule" name="dynamic_working_schedule">
                            <option selected disabled>აირჩიეთ</option>
                            <?php $__currentLoopData = $dynamicWorkingScheduleTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($i); ?>" data-user-id="<?php echo e($student->user_id); ?>"
                                        data-month-day="<?php echo e($dynamicTime->id); ?>" <?php echo e(optional($dy)->dynamic_working_schedule_time_id == $dynamicTime->id ? 'selected' : ''); ?>><?php echo e($dynamicTime->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <?php if($date->isSunday()): ?>
                    <th><?php echo e($student->dynamic_working_schedule()->whereDate('date','>=', \Carbon\Carbon::parse($year.'-'.$month.'-'.$converted)->startOfWeek())->whereDate('date','<=', \Carbon\Carbon::parse($year.'-'.$month.'-'.$converted)->endOfWeek())->get()->sum('workedHours') ?? ''); ?> / 40</th>
                    <?php endif; ?>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script>
    $(document).ready(function () {
        $(".dynamic_working_schedule").change(function () {
            let selectedOption = $(this).find("option:selected");
            let monthDay = selectedOption.data("month-day");

            // Clear the selected attribute from all options
            $(this).find("option").removeAttr("selected");

            // Set the selected attribute for the corresponding day option
            $(this).find("option[data-month-day='" + monthDay + "']").prop("selected", true);

            let day = $(this).find("option[data-month-day='" + monthDay + "']").val();
            let user = selectedOption.data('user-id');
            $.ajax({
                url: "<?php echo e(route('dynamic.working.schedule.update')); ?>",
                method: "POST", // Or "GET" depending on your needs
                data: {
                    schedule_time: monthDay,
                    'month': '<?php echo e($month); ?>',
                    'year': '<?php echo e($year); ?>',
                    day: day,
                    user_id: user,
                    '_token': '<?php echo e(csrf_token()); ?>' }, // Sending the selected day as data
                success: function(response) {
                    // Handle the AJAX response here
                    console.log("AJAX response:", response);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", error);
                }
            });
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\hrms\resources\views/general/working_schedule/dynamic_working_schedule.blade.php ENDPATH**/ ?>